﻿using System;
using System.Collections.Generic;
namespace ClassSchoolPortal
{
    public class Class1
    {
        //Вычисление количество прогулов за месяц за период обращение по болезни.
        public int[] GetCountTruancy1(List<Mark> marks)
        {
            int[] count = new int[12];

            foreach (Mark mark in marks)
            {
                if (mark.Estimation == "б")
                {
                    count[mark.Date.Month - 1] = +1;
                }
            }
            return count;
        }
        //Вычисление среднего арифметического значения оценки в меньшую сторону обращение

        public double MinAVG(string[] marks)
        {
            int i = 0;
            int summa = 0;
            foreach (string mark in marks)
            {
                if (int.TryParse(mark, out int estim))
                {
                    summa += estim;
                    i++;
                }
            }
            return (double)Math.Floor((decimal)(summa / i));
        }

        //Генерация номера студенческого билета в 
        public string GetStudNumber(Students stud)
        {
            string[] FIO = stud.fio.Split();
            return $"{stud.year.ToString("yyyy")}.{stud.group}.{FIO[0][0]}{FIO[1][0]}{FIO[2][0]}";
        }

        //Вычисление количество прогулов за месяц за период обращение по прогулам.

        public int[] GetCountTruancy(List<Mark> marks)
        {
            int[] count = new int[12];

            foreach (Mark mark in marks)
            {
                if (mark.Estimation == "н")
                {
                    count[mark.Date.Month - 1] = +1;
                }
            }
            return count;
        }
        //Генерация оценок, посещаемости на 10 дней вперед, начиная с текущей даты со списком переданных студентов.
        public List<Mark> GetMarks(DateTime date, List<Students> stud)
        {
            string[] estimation = { "2", "3", "4", "5", "п", "н", "б" };
            List<Mark> marks = new List<Mark>();
            foreach (Students student in stud)
            {
                marks.Add(new Mark
                    (
                        date,
                        estimation[new Random().Next(0, estimation.Length)],
                        student)
                    );
            }
            return marks;
        }


        //Класс оценок.
        public class Mark
        {
            public DateTime Date { get; set; }
            public string Estimation { get; set; }
            Students Student { get; set; }
            public Mark(DateTime date, string estimation, Students students)
            {
                Date = date;
                Estimation = estimation;
                Student = students;
            }
        }
        //Класс студентов.
        public class Students
        {
            public int year { get; set; }
            public int group { get; set; }
            public string fio { get; set; }
            public Students(int y, int g, string FIO)
            {
                year = y;
                group = g;
                fio = FIO;
            }
        }

    }
}

